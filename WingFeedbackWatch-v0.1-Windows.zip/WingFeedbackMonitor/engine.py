import os
os.environ.setdefault('SD_ENABLE_ASIO','1')
try:
    import sounddevice as sd
except (OSError, ImportError):
    sd = None  # Demo and saved-event review remain usable without an audio driver.
import json, queue, threading, time, uuid
from pathlib import Path
from datetime import datetime
import numpy as np
from scipy.io import wavfile
from core import Ring, Detector, demo_block

class Engine(threading.Thread):
    def __init__(self, config, directory):
        super().__init__(daemon=True)
        self.config=config; self.directory=Path(directory)
        self.quit=threading.Event(); self.messages=queue.Queue(maxsize=100)
        self.latest=None; self.error=''; self.saved=0; self.scheduled=0; self.gaps=0
    def send(self, kind, payload):
        try: self.messages.put_nowait((kind,payload))
        except queue.Full: self.error='Interface backlog: an event notification was dropped; saved files remain on disk.'
    def run(self):
        c=self.config; rate=c['rate']; channels=c['channels']; block=1024
        ring=Ring(int((c['pre']+.3)*rate)+4096,channels)
        detector=Detector(rate,channels,c['prominence'],c['floor'],c['hold'])
        pending={}; frame=0; rng=np.random.default_rng(420); stream=None
        try:
            self.directory.mkdir(parents=True,exist_ok=True)
        except OSError as exc:
            self.error=f'Recording folder unavailable: {exc}'
            self.send('warning',self.error);self.send('stopped',None);return
        jobs=queue.Queue(maxsize=64)
        def write_clips():
            while True:
                job=jobs.get()
                if job is None: return
                event,audio=job
                try:
                    stem=self.directory/event['id']
                    wavfile.write(str(stem)+'.wav',rate,audio)
                    event['wav']=str(stem)+'.wav'
                    (Path(str(stem)+'.json')).write_text(json.dumps(event,indent=2),encoding='utf-8')
                    self.saved+=1; self.send('event',event)
                except Exception as exc:
                    self.error=f'Clip could not be saved: {exc}'; self.send('warning',self.error)
        writer=threading.Thread(target=write_clips,daemon=True);writer.start()
        def finish(ch):
            event=pending.pop(ch)
            audio=np.concatenate(event.pop('_parts')).astype(np.float32)
            event.pop('_remaining',None)
            event['duration']=len(audio)/rate
            event['complete_postroll']=len(audio)>=round((event['trigger_seconds']+c['post'])*rate)
            try:
                jobs.put_nowait((event,audio));self.scheduled+=1
            except queue.Full:
                self.error='Clip writer backlog full: clip dropped; analysis continues.'
                self.send('warning',self.error)
        try:
            if not c['demo']:
                if sd is None: raise RuntimeError('Audio library unavailable. Reinstall requirements and the device driver.')
                stream=sd.InputStream(device=c['device'],samplerate=rate,channels=channels,
                                      dtype='float32',blocksize=block)
                stream.start()
            self.send('started',None)
            next_time=time.perf_counter()
            while not self.quit.is_set():
                if c['demo']:
                    x=demo_block(frame,block,rate,channels,rng)
                    next_time+=block/rate
                    if self.quit.wait(max(0,next_time-time.perf_counter())): break
                else:
                    if not stream.active: raise RuntimeError('Audio capture stopped. Check device and clock.')
                    x,overflow=stream.read(block)
                    if overflow:
                        self.gaps+=1
                        # Never bridge persistence or pre-roll across missing audio.
                        for ch in list(pending):
                            pending[ch]['audio_gap']=True; finish(ch)
                        ring=Ring(len(ring.data),channels)
                        detector.duration[:]=0; detector.prev[:]=0
                        self.send('warning','Audio overflow: continuity reset. Increase driver buffer or reduce load.')
                for ch in list(pending):
                    e=pending[ch]; take=min(len(x),e['_remaining'])
                    e['_parts'].append(x[:take,ch].copy()); e['_remaining']-=take
                    if e['_remaining']<=0: finish(ch)
                ring.append(x); frame+=len(x)
                if frame%(block*4): continue
                now=frame/rate
                events,db=detector.analyze(ring.tail(4096),now,block*4/rate)
                if db is None: continue
                levels=20*np.log10(np.maximum(np.sqrt(np.mean(x*x,axis=0)),1e-10))
                self.latest=(now,detector.freq,db,levels,detector.score.copy(),self.gaps)
                for d in events:
                    if d.channel in pending: continue
                    if self.scheduled+len(pending)>=c['max_clips']:
                        self.error='Session clip limit reached. Analysis continues; restart capture for a new clip allowance.'
                        continue
                    pre=ring.tail(round(c['pre']*rate))[:,d.channel]
                    stamp=datetime.now().astimezone().isoformat(timespec='seconds')
                    eid=datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]
                    pending[d.channel]={
                        'id':eid,'time':stamp,'channel':d.channel+1,'name':c['names'][d.channel],
                        'frequency':d.frequency,'level':d.level,'prominence':d.prominence,
                        'label':d.label,'rate':rate,'source':c['source'],'demo':c['demo'],
                        'device_label':c['device_label'],'trigger_seconds':len(pre)/rate,
                        'audio_gap':False,'settings':{k:c[k] for k in ('floor','hold','prominence')},
                        '_parts':[pre.copy()],'_remaining':round(c['post']*rate)}
                    self.send('detected',pending[d.channel]['channel'])
        except Exception as exc:
            self.error=f'Capture stopped: {exc}'; self.send('warning',self.error)
        finally:
            if stream is not None:
                stream.stop(); stream.close()
            for ch in list(pending): finish(ch)
            jobs.put(None);writer.join()
            self.send('stopped',None)

class Player(threading.Thread):
    """A separate explicit output stream; never uses the capture device for replay."""
    def __init__(self,audio,rate,device):
        super().__init__(daemon=True); self.audio=audio; self.rate=rate; self.device=device
        self.quit=threading.Event(); self.error=''
    def run(self):
        try:
            with sd.OutputStream(device=self.device,samplerate=self.rate,channels=1,dtype='float32') as s:
                for offset in range(0,len(self.audio),1024):
                    if self.quit.is_set(): break
                    s.write(self.audio[offset:offset+1024,None])
        except Exception as exc: self.error=f'Playback failed: {exc}'
