@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 echo Install Python 3.12 or 3.13, 64-bit, from python.org with the Python launcher enabled.
 pause
 exit /b 1
)
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
if errorlevel 1 goto :failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :failed
echo Installation complete. Run Start-Windows.cmd.
pause
exit /b 0
:failed
echo Installation failed. Review the error above.
pause
exit /b 1
