"""Audio-only analysis. No console control, socket, MIDI, OSC or routing API."""
from dataclasses import dataclass
import numpy as np
from scipy.signal import find_peaks, butter, sosfiltfilt

@dataclass
class Detection:
    channel: int
    frequency: float
    level: float
    prominence: float
    label: str = 'Suspected ringing'

class Ring:
    def __init__(self, frames, channels):
        self.data = np.zeros((frames, channels), np.float32)
        self.pos = 0
        self.size = 0
    def append(self, x):
        x = np.asarray(x, dtype=np.float32)[-len(self.data):]
        n = len(x); first = min(n, len(self.data)-self.pos)
        self.data[self.pos:self.pos+first] = x[:first]
        if first < n: self.data[:n-first] = x[first:]
        self.pos = (self.pos+n) % len(self.data)
        self.size = min(len(self.data), self.size+n)
    def tail(self, count=None):
        n = min(self.size, count if count is not None else self.size)
        start = (self.pos-n) % len(self.data)
        if start+n <= len(self.data): return self.data[start:start+n].copy()
        return np.concatenate((self.data[start:], self.data[:n-(len(self.data)-start)]))

class Detector:
    """Heuristic narrowband detector, NOT a feedback classifier or safety limiter."""
    def __init__(self, rate, channels, prominence=16, floor=-65, hold=.45):
        self.rate, self.channels = rate, channels
        self.prominence, self.floor, self.hold = prominence, floor, hold
        self.nfft = 4096
        self.window = np.hanning(self.nfft)
        self.freq = np.fft.rfftfreq(self.nfft, 1/rate)
        self.prev = np.zeros(channels)
        self.duration = np.zeros(channels)
        self.last_event = np.full(channels, -1e9)
        self.score = np.zeros(channels)
    def analyze(self, samples, now, dt):
        if len(samples)<self.nfft: return [], None
        spec = np.abs(np.fft.rfft(samples[-self.nfft:]*self.window[:,None], axis=0))*2/self.window.sum()
        db = 20*np.log10(np.maximum(spec, 1e-10))
        events = []; self.score[:] = 0
        for ch in range(self.channels):
            peaks, props = find_peaks(db[:,ch], prominence=self.prominence, distance=3)
            valid = (self.freq[peaks]>=100)&(self.freq[peaks]<=min(16000,self.rate*.45))&(db[peaks,ch]>=self.floor)
            peaks=peaks[valid]; proms=props['prominences'][valid]
            if not len(peaks): self.duration[ch]=0; self.prev[ch]=0; continue
            # Prefer strongest audible peak; prominence is evaluated independently.
            pidx = int(np.argmax(db[peaks,ch])); p=int(peaks[pidx]); f=self.freq[p]
            # Interpolate the peak in log magnitude for a finer frequency estimate.
            a,b,c=db[p-1:p+2,ch]; den=a-2*b+c
            offset=float(np.clip(.5*(a-c)/den,-.5,.5)) if abs(den)>1e-9 else 0
            f += offset*self.rate/self.nfft
            if abs(f-self.prev[ch]) <= max(18,f*.012): self.duration[ch]+=dt
            else:
                self.duration[ch]=dt
                self.prev[ch]=f
            self.score[ch]=min(1,self.duration[ch]/self.hold)
            if self.duration[ch]>=self.hold and now-self.last_event[ch]>=8:
                events.append(Detection(ch,float(f),float(db[p,ch]),float(proms[pidx])))
                self.last_event[ch]=now
        return events, db

def filtered_audio(audio, rate, center, bandwidth, mode):
    if mode=='Full clip': return audio.copy()
    lo=max(20,center-bandwidth/2); hi=min(rate*.48,center+bandwidth/2)
    if hi<=lo: raise ValueError('Frequency band is outside the clip sample rate.')
    sos=butter(4,[lo,hi],btype='bandpass',fs=rate,output='sos')
    band=sosfiltfilt(sos,audio).astype(np.float32)
    return band if mode=='Selected band' else audio-band

def demo_block(start, frames, rate, channels, rng):
    t=(start+np.arange(frames))/rate
    x=rng.normal(0,.0015,(frames,channels)).astype(np.float32)
    for ch in range(channels):
        # Moving harmonic material plus periodically injected, quiet narrowband ringing.
        phase=2*np.pi*(130+ch*11)*t + 120*np.sin(2*np.pi*.8*t)
        x[:,ch]+=(.004*np.sin(phase)+.002*np.sin(2*phase)).astype(np.float32)
        cycle=(t+ch*2)%18
        envelope=np.clip((cycle-7)*3,0,1)*np.clip((12-cycle)*3,0,1)
        x[:,ch]+=(.018*envelope*np.sin(2*np.pi*(1250+ch*310)*t)).astype(np.float32)
    return x
