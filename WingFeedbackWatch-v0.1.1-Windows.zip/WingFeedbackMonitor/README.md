# WING Feedback Watch — Windows prototype v0.1.1

A separate desktop audio diagnostic tool for suspected narrowband ringing. Not affiliated with Behringer, Audinate, or Waves. This is an initial working prototype, not validated show-critical software.

## Install and start

1. Extract this ZIP to a normal writable folder, such as `C:\WingFeedbackWatch`.
2. Install **Python 3.13 or 3.12, Windows x86-64 (64-bit)** from https://www.python.org/downloads/windows/ and include the Python launcher. The installer explicitly tries 3.13, then 3.12, then a compatible `python` on PATH. Other versions and architectures are rejected.
3. Double-click **Install-Windows.cmd**. Internet is required to install the dependencies. This creates a Python environment inside the extracted folder; no Windows service or administrator rights are required.
4. Double-click **Start-Windows.cmd**.
5. Leave **Demo** checked and click **Start monitoring**. Generated ringing appears on successive inputs. Open **Detection review** after roughly 10–15 seconds. Saved clips are clearly labelled DEMO.
6. For hardware: stop, uncheck Demo, choose the source profile and actual input device, and set the first N input channels and matching sample rate. Start with 8 channels at 48 kHz. Double-click channel names in the Live monitor table while stopped to label their actual WING channel assignments.

### Installation repair in v0.1.1

The previous installer used `py -3`, which could choose an unsupported interpreter and cause pip to attempt compiling NumPy. This installer selects a compatible interpreter, upgrades pip, and requires prebuilt wheels for every dependency. It preserves an incompatible `.venv` as `.venv-before-install-fix` before rebuilding it. A compatible existing environment is reused. Recorded events and profiles in `%LOCALAPPDATA%\WingFeedbackWatch` are unaffected.

For the simplest repair, extract v0.1.1 into a fresh folder and run Install-Windows.cmd. If Python is not found, install the x86-64 version above and rerun. If it reports no matching distribution, send the full installer output, including the selected Python path/version. Do not install compilers to resolve this error. This installer change has not been executed on Windows here.

This package contains Python source and launch scripts, not a compiled EXE. Windows driver capture and headphone playback must be verified on the target PC.

## Three selectable audio sources

- **WING USB:** install the manufacturer's Windows USB audio driver and manually route the desired WING sends to USB. Choose the ASIO input entry when available.
- **Dante:** install/license Dante Virtual Soundcard or use a compatible hardware audio driver. Patch the desired sources to the PC using Dante Controller. Select the matching input driver.
- **Waves SoundGrid:** install the Waves recording driver and patch it in your SoundGrid host. Select its ASIO input entry. SuperRack Performer alone does not provide a SoundGrid feed; its underlying audio device would need an available capture path.

The three source selectors save independent **local profiles**. They do not configure console or network routing. All detected input drivers remain available in each profile so driver naming differences do not prevent selection. One audio device is active at a time; switching sources requires stopping capture. Existing saved clips remain available.

The current channel map is the **first N driver input slots**, with editable names. A stream slot is not necessarily the same-numbered WING processing channel. Stereo sources consume two audio slots. Sample rate must match the system clock. Driver sharing with a DAW/SuperRack and simultaneous ASIO capture with another output driver depend on the drivers and require testing; use a separate monitoring PC if necessary.

## Graphs and charts

- **Live spectrum:** selected input's FFT magnitude with a logarithmic frequency axis.
- **Recent level:** selected input's RMS level over the past 30 seconds.
- **Event waveform:** recorded mono audio, with a vertical marker at the detection trigger.
- **Event spectrum:** maximum spectral magnitude over the clip; click a frequency to set the replay band.
- **Spectrogram:** frequency versus time; brighter colors mean stronger tones. It displays up to 12 kHz; capture and the full spectrum retain the complete audio bandwidth.
- **Analytics:** saved detections by input, frequency distribution, and a frequency/time scatter plot. Timeline colors identify demo versus live events. Analytics cover up to the latest 500 loaded events, include both live and demo, and count saved alerts rather than feedback severity or total ringing duration.
- **CSV export:** export the loaded detections for further analysis. Metadata WAV paths are local to the recording PC.

## Continuous analysis and event recordings

Audio capture/detection runs in a background thread. Clip writing has its own bounded queue. Browsing, plotting, filtering, and playback do not intentionally pause analysis. Computer overload or slow drivers can still cause dropouts; the app reports capture overflows and resets continuity across gaps.

Default clips retain **5 seconds before** the alert and **5 seconds after**. Both are adjustable from 1–10 seconds. The trigger is the moment persistence criteria are met, not necessarily the onset of ringing. The first clip after startup may have less pre-roll. Stopping flushes pending clips with available post-roll, marked partial. Events have an 8-second cooldown per input to limit duplicates; very long ringing may therefore create repeated events, and a new tone on the same input during cooldown may not produce another clip.

Audio is saved without normalization as mono float WAV, with matching JSON metadata. No automatic cloud upload or continuous full-show recording. On Windows the location is:

`%LOCALAPPDATA%\WingFeedbackWatch\events`

Profiles are stored beside that folder. Recordings may contain speech and should be handled like other show recordings. They are **not automatically deleted**. The default limit is 200 clips per capture session; once reached, analysis continues but new clips stop, with a status message. Restarting capture resets this allowance. At 48 kHz a 10-second mono float clip is roughly 1.9 MB. Clip writer backlog is bounded; if full, a dropped-clip warning is displayed.

## Frequency audition

Select an event, then choose:

- **Full clip:** unfiltered captured audio.
- **Selected band:** a fourth-order bandpass around the target frequency.
- **Band removed:** the full clip minus that filtered component.

Set center frequency and bandwidth, or click the event spectrum, then click Play. Playback restarts from the beginning when changing modes; there is no synchronized A/B transport or scrubbing yet. Filtering runs only on the saved clip and is not an EQ suggestion or change to the live mix. The app does not normalize the isolated band, so quieter content stays quiet. Default replay attenuation is -18 dB, adjustable up to 0 dB.

Explicitly choose a **separate local headphone output**. Known WING/Dante/SoundGrid/ASIO/virtual output names are excluded, and there is no default playback device. Driver names cannot prove physical routing: verify the selected output really feeds headphones. Some Windows driver combinations cannot run capture and review output concurrently; this needs testing on the event PC. Capture uses InputStream; replay alone uses a separate OutputStream. No audio is intentionally returned to the console.

## Read-only scope

The application contains **no OSC, MIDI, console-control or routing API**, no socket code, and no fader/EQ/gain/mute controls. It captures the audio feed configured by the operator. All adjustable controls affect local analysis, recordings, or clip replay. Audio drivers may negotiate device format/clock behavior; the app does not send mixer parameter changes. Setup routing is performed manually outside this app. This version has no channel-name synchronization or WING IP setting.

## What the detector can and cannot say

The current detector is a prototype heuristic: a 4096-sample Hann-window FFT, evaluated every 4096 samples, searches for persistent, prominent spectral peaks from 100 Hz to the lesser of 16 kHz and 45% of sample rate. Defaults: minimum peak-bin level -65 dBFS, prominence 16 dB, persistence 0.45 seconds. It tracks the strongest qualifying peak per input and estimates frequency with log-magnitude interpolation. At 48 kHz FFT spacing is about 11.7 Hz; an interpolated decimal is an estimate, not guaranteed measurement precision.

The displayed ringing score is **progress toward the persistence threshold**, not a probability that feedback exists. Tone level is a window-corrected FFT-bin estimate, not calibrated room SPL. A single strongest-peak tracker can miss quieter simultaneous ringing, especially under vocals/instruments. It has no learned room baseline, mix-bus coherence analysis, channel culprit inference, or trained speech/music classifier yet. Sustained singing/instruments can trigger alerts. Noise and program material can hide real feedback. A raw source tap may flag microphones whose channel fader is down. Multiple microphones can capture the same acoustic tone.

It cannot guarantee instant detection or warnings before feedback is audible. Detectable timing depends on signal, persistence, buffer size, and sample rate. Use rehearsal recordings and safe normal operation to tune thresholds; do not deliberately drive the PA into feedback to test it. This app is an assistant for an operator, not feedback suppression or hearing/speaker protection.

## Validation for this release

- Automated synthetic tests: circular pre-roll buffer order; quiet 2.5 kHz tone detection on the correct input; noise/short-tone rejection; filtered-band isolation and reconstruction; generated demo tone detection.
- Offscreen Qt integration: demo capture, recorded WAV/JSON events, event review, all graph pages, analysis advancing during review, and stop/clip flush.
- Not validated here: a physical WING, Windows audio drivers, USB/Dante/SoundGrid routing, actual headphone playback, long-duration/high-channel-count performance, or real-world false-positive/false-negative rates.

Run core checks from this folder with `.venv\Scripts\python.exe -m unittest -v test_core.py`.

## Technical references

- WING: https://www.behringer.com/en/wing/wing-black
- Dante audio application compatibility: https://support.getdante.com/hc/en-gb/articles/5502036583583-Which-audio-applications-does-Dante-Virtual-Soundcard-support
- SoundGrid recording driver setup: https://www.waves.com/support/add-a-recording-playback-computer-to-a-soundgrid-network
- Windows ASIO capture implementation: https://python-sounddevice.readthedocs.io/en/0.5.5/installation.html
